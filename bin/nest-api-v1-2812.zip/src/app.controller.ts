import { Controller, Get, Param } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { AppService } from "./app.service";
import { sampleData } from "./data/sample.data";
import * as _ from "lodash";

@ApiTags("main")
@Controller("app")
export class AppController {
  constructor(private readonly appService: AppService) {
  }

  @Get("hello")
  getHello(): string {
    return this.appService.getHello();
  }

  @Get("data")
  getData(): any {
    return sampleData.data();
  }

  @Get("paged-data/skip/:skip/take/:take")
  getPagedData(@Param('skip') skip: number, @Param('take') take: number): any {
    const data =  sampleData.data();
    const paged = _(data).drop(skip).take(take).value();
    console.log(skip);
    return paged;
  }

  @Get("accounts")
  getAccounts(): any{
    return [
      6592626121,
      6595561212,
      6562612546,
      6292632323
    ];
  }
}


