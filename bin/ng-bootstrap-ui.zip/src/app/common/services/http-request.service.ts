import { Injectable } from '@angular/core';
import {Observable} from "rxjs";
import {ajax, AjaxResponse} from "rxjs/ajax";

@Injectable({
  providedIn: 'root'
})
export class HttpRequestService {

  constructor() { }

  get<T>(url: string, headers?: Record<string, string>): Observable<AjaxResponse<T>>{
    return ajax.get(url);
  }

  post<T>(url: string, body?: any, headers?: Record<string, string>): Observable<AjaxResponse<T>>{
    return ajax.post(url, body, headers);
  }
}
