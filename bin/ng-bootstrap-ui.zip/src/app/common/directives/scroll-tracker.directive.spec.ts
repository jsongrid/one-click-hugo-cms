import { ScrollTrackerDirective } from './scroll-tracker.directive';

describe('ScrollTrackerDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollTrackerDirective();
    expect(directive).toBeTruthy();
  });
});
