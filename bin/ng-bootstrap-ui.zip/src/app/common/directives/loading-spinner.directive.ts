import {
  Component,
  ComponentFactoryResolver,
  Directive,
  Input,
  TemplateRef,
  ViewContainerRef,
} from '@angular/core';

@Component({
  template: `
    <div class='overlay'>
      <!--<mat-progress-spinner mode='indeterminate' [diameter]='diameter' color='accent'></mat-progress-spinner>-->
      <div class="spinner-border text-secondary" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>`,
  styles: [`
    .overlay {
      position: absolute;
      height: 100%;
      width: 100%;
      z-index: 2;
      display: flex;
      justify-content: center;
      align-items: center;
      left: 0;
      top: 0;
    }
  `],
})
export class SpinnerComponent {
  public diameter = 0;
}

export class SpinnerParams {
  constructor(public isLoaded: boolean,
              public displayWhileLoading = false, // show/inject template while loading
              public diameter = 50,
  ) {
  }
}

@Directive({
  selector: '[appLoadingSpinner]',
})
export class LoadingSpinnerDirective {
  _spinnerParams: SpinnerParams = {
    isLoaded: true,
    displayWhileLoading: true,
    diameter: 50
  };

  get appLoadingSpinner(): SpinnerParams {
    return this._spinnerParams;
  }

  @Input('appLoadingSpinner') set appLoadingSpinner(value: SpinnerParams) {
    this._spinnerParams = Object.assign(new SpinnerParams(value.isLoaded), value);
    this.update();
  }

  constructor(private templateRef: TemplateRef<void>,
              private vcr: ViewContainerRef,
              private cfr: ComponentFactoryResolver) {
  }

  private update(): void {
    const parentElement = this.vcr.element.nativeElement.parentElement;
    if (!this._spinnerParams.isLoaded) {
      this.vcr.clear();
      parentElement.classList.add('position-relative');
      const cmpFactory = this.cfr.resolveComponentFactory(SpinnerComponent);
      const componentRef = this.vcr.createComponent(cmpFactory);
      componentRef.instance.diameter = this._spinnerParams.diameter;
      if (this._spinnerParams.displayWhileLoading) {
        this.vcr.createEmbeddedView(this.templateRef);
      }
    } else {
      this.vcr.clear();
      parentElement.classList.remove('position-relative');
      this.vcr.createEmbeddedView(this.templateRef);
    }
  }
}
