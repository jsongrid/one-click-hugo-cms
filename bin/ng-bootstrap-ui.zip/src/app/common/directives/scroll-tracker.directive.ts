import {Directive, EventEmitter, HostListener, Output} from '@angular/core';
import * as _ from 'lodash';
@Directive({
  selector: '[appScrollTracker]'
})
export class ScrollTrackerDirective {
  @Output() scrollReachedEnd = new EventEmitter<any>();
  private debouncedFunc = _.debounce(() =>
    this.scrollReachedEnd.emit({})
    , 100, {});
  constructor() { }
  @HostListener('scroll', ['$event'])
  onScroll(event: any) {
    let tracker = event.target;
    let limit = tracker.scrollHeight - tracker.clientHeight;
    console.log(`scrollHeight:${tracker.scrollHeight} clientHeight: ${tracker.clientHeight} limit: ${limit}`)
    const scrollTop = Math.ceil(event.target.scrollTop);
    //const scrollTop = event.target.scrollTop;
    if (scrollTop === limit) {
      this.scrollReachedEnd.emit({});
    }
  }
}
