import { LoadingSpinnerDirective } from './loading-spinner.directive';

describe('LoadingSpinnerDirective', () => {
  it('should create an instance', () => {
    const directive = new LoadingSpinnerDirective();
    expect(directive).toBeTruthy();
  });
});
