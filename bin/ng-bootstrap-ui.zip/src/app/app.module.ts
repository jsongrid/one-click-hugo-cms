import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {NgbModule} from "@ng-bootstrap/ng-bootstrap";
import { BillingPaymentComponent } from './billing-payment/billing-payment.component';
import { AmountOwingComponent } from './billing-payment/amount-owing/amount-owing.component';
import { CurrentInvoiceComponent } from './billing-payment/current-invoice/current-invoice.component';
import { BillingDetailsComponent } from './billing-payment/billing-details/billing-details.component';
import {LoadingSpinnerDirective, SpinnerComponent} from './common/directives/loading-spinner.directive';
import { AccountsComponent } from './billing-payment/accounts/accounts.component';
import {ToastsContainer} from "./common/services/toast.service";
import { ScrollTrackerDirective } from './common/directives/scroll-tracker.directive';

@NgModule({
  declarations: [
    AppComponent,
    BillingPaymentComponent,
    AmountOwingComponent,
    CurrentInvoiceComponent,
    BillingDetailsComponent,
    LoadingSpinnerDirective,
    SpinnerComponent,
    AccountsComponent,
    ScrollTrackerDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    ToastsContainer
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
