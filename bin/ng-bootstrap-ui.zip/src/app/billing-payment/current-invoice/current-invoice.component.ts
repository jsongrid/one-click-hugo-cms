import {Component, OnInit} from '@angular/core';
import { ajax } from 'rxjs/ajax';
import {HttpRequestService} from "../../common/services/http-request.service";
@Component({
  selector: 'app-current-invoice',
  templateUrl: './current-invoice.component.html',
  styleUrls: ['./current-invoice.component.scss']
})
export class CurrentInvoiceComponent implements OnInit{
  dataLoaded = true;

  constructor(httpReq: HttpRequestService) {
  }

  ngOnInit() {
    this.dataLoaded = false;
    setTimeout(() => {
      this.dataLoaded = true;
    }, 3000);


  }

  private loadInvoice(){

  }
}
