import {Component, OnInit} from '@angular/core';
import {HttpRequestService} from "../../common/services/http-request.service";

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.scss']
})
export class AccountsComponent implements OnInit{

  selected = '';
  accounts: string[] = [];
  accountsBound: string[] = [];
  constructor(private httpReq: HttpRequestService) {
  }
  ngOnInit() {
    console.log(`just checking`);
    this.selected = 'Loading...';
    this.httpReq.get<string[]>('http://localhost:3000/app/accounts').subscribe(data => {
      this.accounts = data.response;
      this.selected = this.accounts[0];
      this.accountsBound = this.accounts.filter(c => c !== this.selected);
    })
  }

  selectValue(value: string): void{
    this.selected = value;
    this.accountsBound = this.accounts.filter(c => c !== this.selected);
  }
}
