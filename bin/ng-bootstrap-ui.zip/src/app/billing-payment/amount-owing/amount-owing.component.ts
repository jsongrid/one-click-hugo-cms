import { Component } from '@angular/core';

@Component({
  selector: 'app-amount-owing',
  templateUrl: './amount-owing.component.html',
  styleUrls: ['./amount-owing.component.scss']
})
export class AmountOwingComponent {

}
