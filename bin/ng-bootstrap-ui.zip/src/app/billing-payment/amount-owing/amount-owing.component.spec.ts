import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AmountOwingComponent } from './amount-owing.component';

describe('AmountOwingComponent', () => {
  let component: AmountOwingComponent;
  let fixture: ComponentFixture<AmountOwingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AmountOwingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AmountOwingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
