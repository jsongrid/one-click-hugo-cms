import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {HttpRequestService} from "../../common/services/http-request.service";
import {ToastService} from "../../common/services/toast.service";


@Component({
  selector: 'app-billing-details',
  templateUrl: './billing-details.component.html',
  styleUrls: ['./billing-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class BillingDetailsComponent implements OnInit {
  countries: Country[] = [];
  dataLoaded = true;
  skip = 0;
  showPagingProgress = false;
  take = 10;
  pageRequestLock = false;
  constructor(private httpReq: HttpRequestService, private toastService: ToastService) {
  }

  scrollReachedEnd($event: any){
    if(this.pageRequestLock){
      return;
    }
    this.pageRequestLock = true;
    this.showPagingProgress = true;
    this.httpReq.get<Country[]>(`http://localhost:3000/app/paged-data/skip/${this.skip}/take/${this.take}`).subscribe(
      {
        next: (data) => {
          this.skip += this.take;
          this.countries.push(...data.response);
          this.showPagingProgress = false;
          this.pageRequestLock = false;
        },
        error: (err) => {
          console.log(`error`, err)
          this.toastService.error('Error occurred')
          this.showPagingProgress = false;
          this.pageRequestLock = false;
        }
      }
    )
  }
  ngOnInit() {
    this.dataLoaded = false;
    this.httpReq.get<Country[]>('http://localhost:3000/app/paged-data/skip/0/take/20').subscribe(
      {
        next: (data) => {
          this.countries = data.response;
          this.dataLoaded = true;
          this.skip = 20;
        },
        error: (err) => {
          console.log(`error`, err)
          this.toastService.error('Error occurred')
          this.dataLoaded = true;
        }
      }
    )
  }

  openPdf(country: Country) {
    window.open("https://www.africau.edu/images/default/sample.pdf", '_blank');
  }
}

interface Country {
  _id: string,
  index: number,
  name: string;
  balance: number;
  registered: Date;
}
